// app/admin/layout.tsx
"use client";

import { useState } from "react";
import Sidebar from "./components/shared/sidebar";
import Topbar from "./components/shared/topbar";
import "./styles/admin.css";
import "boxicons/css/boxicons.min.css";


export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen overflow-hidden">
      {sidebarOpen && (
        <div className="hidden lg:block">
          <Sidebar onToggleSidebar={() => setSidebarOpen(false)} />
        </div>
      )}
      <div className="flex-1 flex flex-col">
        <Topbar onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />
        <main className="flex-1 overflow-y-auto p-4 bg-main">
            {children}
        </main>


      </div>
    </div>
  );
}
