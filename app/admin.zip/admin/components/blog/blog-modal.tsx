"use client";

import React, { useState, useEffect } from "react";
import { Dialog, Switch } from "@headlessui/react";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import Image from "next/image";
import { toast } from 'react-toastify';

interface AddBlogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  initialData?: any;
  isEdit?: boolean;
}

export default function AddBlogModal({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  isEdit = false,
}: AddBlogModalProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [content, setContent] = useState("");
  const [images, setImages] = useState<(File | string)[]>([]);
  const [status, setStatus] = useState(true);

  // ✅ Reset & prefill form
  useEffect(() => {
    if (initialData) {
      setTitle(initialData.title || "");
      setDescription(initialData.description || "");
      setContent(initialData.content || "");
      setImages(initialData.images || []);
      setStatus(initialData.status === "published");
    } else {
      setTitle("");
      setDescription("");
      setContent("");
      setImages([]);
      setStatus(true);
    }
  }, [initialData, isOpen]);

  // ✅ Upload ảnh
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validImages = files.filter((file) => file.type.startsWith("image/"));

    if (validImages.length > 0) {
      setImages((prev) => [...prev, ...validImages]);
    } else {
      toast.error("Vui lòng chọn các tệp hình ảnh hợp lệ");
    }
  };

  // ✅ Xoá ảnh
  const handleRemoveImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  // ✅ Gửi dữ liệu
  const handleSubmit = () => {
    if (!title.trim() || !description.trim() || !content.trim()) {
      toast.error("Vui lòng điền đầy đủ thông tin bài viết");
      return;
    }

    const formattedData = {
      ...initialData,
      title,
      description,
      content,
      images,
      status: status ? "published" : "draft",
      date: initialData?.date || new Date().toISOString().split("T")[0],
      isEdit,
    };

    onSubmit(formattedData);
    onClose();
  };

  return (
    <Dialog open={isOpen} onClose={onClose} className="fixed z-50 inset-0 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen bg-black/50 p-4">
        <Dialog.Panel className="bg-white w-full max-w-3xl rounded-lg shadow p-6 space-y-4">
          <Dialog.Title className="text-lg font-bold">
            {isEdit ? "Chỉnh sửa bài viết" : "Thêm bài viết mới"}
          </Dialog.Title>

          {/* Tiêu đề */}
          <div className="space-y-1">
            <label className="text-sm font-medium">Tiêu đề:</label>
            <input
              type="text"
              placeholder="VD: Xu hướng mùa hè 2025"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full border px-4 py-2 rounded-md text-sm"
            />
          </div>

          {/* Mô tả ngắn */}
          <div className="space-y-1">
            <label className="text-sm font-medium">Mô tả ngắn:</label>
            <CKEditor
              editor={ClassicEditor}
              data={description}
              onChange={(_, editor) => setDescription(editor.getData())}
            />
          </div>

          {/* Nội dung */}
          <div className="space-y-1">
            <label className="text-sm font-medium">Nội dung:</label>
            <CKEditor
              editor={ClassicEditor}
              data={content}
              onChange={(_, editor) => setContent(editor.getData())}
            />
          </div>

          {/* Hình ảnh */}
          <div className="space-y-1">
            <label className="text-sm font-medium">Hình ảnh:</label>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleImageChange}
              className="w-full border px-4 py-2 rounded-md text-sm"
            />

            {images.length > 0 && (
              <div className="flex flex-wrap gap-4 mt-2">
                {images.map((img, index) => {
                  const imgUrl = typeof img === "string" ? img : URL.createObjectURL(img);
                  return (
                    <div key={index} className="relative w-32 h-32 rounded overflow-hidden border">
                      <Image
                        src={imgUrl}
                        alt={`Ảnh ${index + 1}`}
                        width={128}
                        height={128}
                        className="object-cover w-full h-full"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(index)}
                        className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs hover:bg-red-600"
                      >
                        ×
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Trạng thái */}
          <div className="flex items-center gap-4 pt-2">
            <label className="text-sm font-medium">Trạng thái:</label>
            <Switch
              checked={status}
              onChange={setStatus}
              className={`${
                status ? "bg-green-500" : "bg-gray-300"
              } relative inline-flex h-6 w-11 items-center rounded-full`}
            >
              <span
                className={`${
                  status ? "translate-x-6" : "translate-x-1"
                } inline-block h-4 w-4 transform rounded-full bg-white transition`}
              />
            </Switch>
            <span className="text-sm">{status ? "Đang hoạt động" : "Ngưng hoạt động"}</span>
          </div>

          {/* Nút hành động */}
          <div className="flex justify-end gap-2 pt-4">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm border rounded-md bg-gray-100 hover:bg-gray-200"
            >
              Đóng
            </button>
            <button
              onClick={handleSubmit}
              className="px-4 py-2 text-sm rounded-md bg-blue-600 text-white hover:bg-blue-700"
            >
              {isEdit ? "Lưu thay đổi" : "+ Thêm bài viết"}
            </button>
          </div>
        </Dialog.Panel>
      </div>
    </Dialog>
  );
}
