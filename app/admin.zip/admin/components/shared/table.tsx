// components/shared/table.tsx
import Image from "next/image";
import { format } from "date-fns";
import clsx from "clsx";

type DataItem = {
  id: number;
  image: string;
  title: string;
  description: string;
  content: string;
  date: string;
  status: "published" | "draft";
};

type Props = {
  data: DataItem[];
  onEdit?: (id: number) => void;
};

export default function Table({ data, onEdit }: Props) {
  return (
    <div className="overflow-x-auto bg-card rounded-lg shadow">
      <table className="min-w-full table-auto text-sm text-left">
        <thead className="bg-secondary text-secondary-foreground">
          <tr>
            <th className="px-4 py-3">Hình ảnh</th>
            <th className="px-4 py-3">Tiêu đề</th>
            <th className="px-4 py-3">Mô tả Ngắn</th>
            <th className="px-4 py-3">Nội dung</th>
            <th className="px-4 py-3">Ngày</th>
            <th className="px-4 py-3">Trạng thái</th>
            <th className="px-4 py-3 text-center">Thao tác</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.id} className="border-t hover:bg-muted transition">
              <td className="px-4 py-2">
              <Image
                src={item.image || "/placeholder.jpg"}
                alt={item.title || "Ảnh blog"}
                width={60}
                height={60}
                className="rounded-md object-cover"
                />
              </td>
              <td className="px-4 py-2">{item.title}</td>
              <td className="px-4 py-2">{item.description}</td>
              <td className="px-4 py-2 line-clamp-2 max-w-[200px]">{item.content}</td>
              <td className="px-4 py-2">
                {format(new Date(item.date), "dd/MM/yyyy")}
              </td>
              <td className="px-4 py-2">
                <span
                  className={clsx(
                    "px-2 py-1 rounded-full text-xs font-medium",
                    item.status === "published"
                      ? "bg-green-200 text-green-700"
                      : "bg-gray-300 text-gray-700"
                  )}
                >
                  {item.status === "published" ? "Công khai" : "Bản nháp"}
                </span>
              </td>
              <td className="px-4 py-2 text-center">
                <button
                    className="bg-yellow-400 hover:bg-yellow-500 text-black px-4 py-2 rounded-md transition inline-flex items-center justify-center"
                    onClick={() => onEdit?.(item.id)}
                    title="Sửa bài viết"
                >
                    <i className="bx bx-pencil text-xl" />
                </button>
                </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
