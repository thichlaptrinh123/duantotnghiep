"use client";

import { useState } from "react";
import Table from "../components/shared/table";
import SearchInput from "../components/shared/search-input";
import StatusFilter from "../components/shared/status-filter";
import AddBlogModal from "../components/blog/blog-modal";

// 1️⃣ Type định nghĩa
export type BlogStatus = "published" | "draft";

export interface Blog {
  id: number;
  images: string[];
  title: string;
  description: string;
  content: string;
  date: string;
  status: BlogStatus;
}

// 2️⃣ Dữ liệu mẫu
const blogData: Blog[] = [
  {
    id: 1,
    images: ["/img/blog-1.jpg"],
    title: "Bài viết đầu tiên",
    description: "Mô tả ngắn gọn",
    content: "Nội dung chi tiết dài hơn...",
    date: "2025-06-15",
    status: "published",
  },
  {
    id: 2,
    images: ["/img/blog-2.jpg"],
    title: "Bài viết nháp",
    description: "Chưa hoàn thiện",
    content: "Nội dung đang cập nhật...",
    date: "2025-06-14",
    status: "draft",
  },
];

export default function BlogPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | BlogStatus>("all");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [blogs, setBlogs] = useState<Blog[]>(blogData);
  const [editBlog, setEditBlog] = useState<Blog | null>(null);
  const [isEditOpen, setIsEditOpen] = useState(false);

  // 4️⃣ Hàm xử lý thêm bài viết
  const handleAddBlog = (newBlog: Omit<Blog, "id">) => {
    const newId = blogs.length + 1;
    const blogWithId: Blog = { id: newId, ...newBlog };
    setBlogs([...blogs, blogWithId]);
  };

  // 5️⃣ Hàm xử lý sửa bài viết
  const handleEdit = (id: number) => {
    const blogToEdit = blogs.find((b) => b.id === id);
    if (blogToEdit) {
      setEditBlog(blogToEdit);
      setIsEditOpen(true);
    }
  };

  // 6️⃣ Lọc dữ liệu hiển thị
  const filteredData = blogs.filter((item) => {
    const matchSearch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchStatus =
      filterStatus === "all" || item.status === filterStatus;

    return matchSearch && matchStatus;
  });

  return (
    <section className="p-4 space-y-6">
      {/* Tiêu đề và bộ lọc */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-semibold text-gray-800">Quản lý Blog</h1>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
          <SearchInput
            value={searchTerm}
            placeholder="Tìm kiếm bài viết..."
            onChange={(value) => setSearchTerm(value)}
          />
          <StatusFilter
            value={filterStatus}
            onChange={(value: string) =>
              setFilterStatus(value as "all" | BlogStatus)
            }
            options={[
              { label: "Tất cả trạng thái", value: "all" },
              { label: "Đã đăng", value: "published" },
              { label: "Nháp", value: "draft" },
            ]}
          />
        </div>
      </div>

      {/* Nút thêm bài viết */}
      <div className="flex justify-end">
        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          + Thêm bài viết
        </button>
      </div>

      {/* Bảng hiển thị */}
      <div className="bg-white rounded-xl shadow overflow-hidden">
        <Table data={filteredData} onEdit={handleEdit} />
      </div>

      {/* Modal thêm / sửa */}
      <AddBlogModal
        isOpen={isModalOpen || isEditOpen}
        onClose={() => {
          setIsModalOpen(false);
          setIsEditOpen(false);
          setEditBlog(null);
        }}
        onSubmit={(data) => {
          if (data.isEdit) {
            setBlogs((prev) =>
              prev.map((item) => (item.id === data.id ? { ...item, ...data } : item))
            );
          } else {
            handleAddBlog(data);
          }
          setIsModalOpen(false);
          setIsEditOpen(false);
          setEditBlog(null);
        }}
        initialData={editBlog}
        isEdit={!!editBlog}
      />
    </section>
  );
}
