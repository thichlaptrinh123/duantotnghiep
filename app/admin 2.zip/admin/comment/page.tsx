"use client";

import React, { useState, useMemo } from "react";
import StatusFilter from "../components/shared/status-filter";
import SearchInput from "../components/shared/search-input";
import Pagination from "../components/shared/pagination";

interface Comment {
  id: number;
  product: {
    name: string;
    image: string;
  };
  user: string;
  content: string;
  rating: number;
  createdAt: string;
  status: "active" | "inactive";
}

const mockComments: Comment[] = [
  {
    id: 1,
    product: {
      name: "Áo thun cổ tròn",
      image: "/images/product1.jpg",
    },
    user: "Nguyễn Văn A",
    content: "Sản phẩm chất lượng, sẽ mua lại.",
    rating: 5,
    createdAt: "2025-06-15",
    status: "active",
  },
  {
    id: 2,
    product: {
      name: "Quần jean xanh",
      image: "/images/product2.jpg",
    },
    user: "Trần Thị B",
    content: "Hơi chật so với size.",
    rating: 3,
    createdAt: "2025-06-14",
    status: "inactive",
  },
  // Thêm dữ liệu mẫu nếu cần
];

export default function CommentPage() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchKeyword, setSearchKeyword] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 5;

  const filteredComments = useMemo(() => {
    return mockComments.filter((c) => {
      const matchesStatus =
        statusFilter === "all" || c.status === statusFilter;
      const matchesKeyword =
        c.product.name.toLowerCase().includes(searchKeyword.toLowerCase()) ||
        c.user.toLowerCase().includes(searchKeyword.toLowerCase()) ||
        c.content.toLowerCase().includes(searchKeyword.toLowerCase());
      return matchesStatus && matchesKeyword;
    });
  }, [statusFilter, searchKeyword]);

  const totalPages = Math.ceil(filteredComments.length / pageSize);
  const paginatedComments = useMemo(() => {
    const startIdx = (currentPage - 1) * pageSize;
    return filteredComments.slice(startIdx, startIdx + pageSize);
  }, [filteredComments, currentPage]);

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <SearchInput
          value={searchKeyword}
          onChange={setSearchKeyword}
          placeholder="Tìm kiếm bình luận..."
        />
        <StatusFilter value={statusFilter} onChange={setStatusFilter} />
      </div>

      <div className="overflow-x-auto border rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Sản phẩm</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Người dùng</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Nội dung</th>
              <th className="px-2 py-2 text-center text-sm font-medium text-gray-600">Số sao</th>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-600">Thời gian</th>
              <th className="px-4 py-2 text-center text-sm font-medium text-gray-600">Trạng thái</th>
              <th className="px-4 py-2 text-center text-sm font-medium text-gray-600">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {paginatedComments.map((item) => (
              <tr key={item.id}>
                <td className="px-4 py-3 flex items-center gap-2">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-10 h-10 rounded-md object-cover"
                  />
                  <span className="text-sm font-medium">{item.product.name}</span>
                </td>
                <td className="px-4 py-2 text-sm">{item.user}</td>
                <td className="px-4 py-2 text-sm line-clamp-2 max-w-xs">
                  {item.content}
                </td>
                <td className="px-2 py-2 text-center text-sm font-semibold text-yellow-600">
                  {item.rating}★
                </td>
                <td className="px-4 py-2 text-sm">{item.createdAt}</td>
                <td className="px-4 py-2 text-center">
                  <span
                    className={`px-2 py-1 text-xs rounded-full font-medium inline-block ${
                      item.status === "active"
                        ? "bg-green-200 text-green-700"
                        : "bg-gray-300 text-gray-700"
                    }`}
                  >
                    {item.status === "active" ? "Hiển thị" : "Đã ẩn"}
                  </span>
                </td>
                <td className="px-4 py-2 text-center">
                  <button
                    className="p-1 rounded hover:bg-gray-100 text-gray-600"
                    title="Ẩn / Hiện"
                  >
                    <i
                      className={`bx bx-$
                        {item.status === "active" ? "hide" : "show"}`}
                    ></i>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
      />
    </div>
  );
}