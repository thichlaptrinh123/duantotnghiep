"use client";

import React from "react";

interface StatusFilterProps {
  value: string;
  onChange: (value: string) => void;
  options?: { label: string; value: string }[];
}

const defaultOptions = [
  { label: "Tất cả trạng thái", value: "all" },
  { label: "Đang hoạt động", value: "active" },
  { label: "Ngưng hoạt động", value: "inactive" },
];

export default function StatusFilter({
  value,
  onChange,
  options = defaultOptions,
}: StatusFilterProps) {
  return (
    <select
      className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      {options.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
  );
}
