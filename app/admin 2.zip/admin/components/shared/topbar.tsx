"use client";
import React from "react";
import toast from "react-hot-toast";

interface TopbarProps {
  onToggleSidebar: () => void;
}

export default function Topbar({ onToggleSidebar }: TopbarProps) {
  const handleLogoutClick = () => {
    toast(
      (t) => (
        <div className="text-sm">
          <p className="mb-2">Bạn có chắc muốn đăng xuất không?</p>
          <div className="flex gap-2 justify-end">
            <button
              onClick={() => {
                toast.dismiss(t.id);
                // 👉 TODO: Gọi hàm đăng xuất tại đây
                console.log("Đăng xuất thành công!");
              }}
              className="bg-[var(--primary-hover)] text-white px-3 py-1 rounded text-sm"
            >
              Đăng xuất
            </button>
            <button
              onClick={() => toast.dismiss(t.id)}
              className="bg-gray-200 text-black px-3 py-1 rounded text-sm"
            >
              Hủy
            </button>
          </div>
        </div>
      ),
      {
        duration: 5000,
      }
    );
  };

  return (
    <header className="flex items-center justify-between px-4 py-3 bg-primary text-white shadow md:pl-6">
      <button
        className="lg:hidden"
        onClick={onToggleSidebar}
        aria-label="Toggle sidebar"
      >
        <i className="bx bx-menu text-2xl"></i>
      </button>

      <h1 className="text-lg font-semibold font-roboto">Trang quản trị</h1>

      <div className="flex items-center space-x-4">
        <button
          onClick={handleLogoutClick}
          className="flex items-center gap-2 transition hover:opacity-80"
        >
          <i className="bx bx-log-out text-xl"></i>
          <span className="hidden sm:inline">Đăng xuất</span>
        </button>
      </div>
    </header>
  );
}
